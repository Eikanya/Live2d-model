import os
import sys
import shutil
import json

if __name__ == '__main__':
    with open('model.json', "r", encoding="utf-8") as f:
        example = json.load(f)
    dirList = os.listdir('DC/')
    for i in dirList:
        del example['textures'][::]
        del example['expressions'][::]
        del example['motions'][''][::]
        pre = 'DC/' + i + '/'
        os.system('cd %s & ren *.dat *.exp.json' % (pre))
        os.system('cd %s & ren *.txt *.mtn' % (pre))
        fileList = os.listdir(pre)
        try:
            os.mkdir(pre + 'expressions/')
        except FileExistsError:
            pass
        try:
            os.mkdir(pre + 'motions/')
        except FileExistsError:
            pass
        try:
            os.mkdir(pre + 'textures/')
        except FileExistsError:
            pass
        expCnt = mtnCnt = textureCnt = 0
        for j in fileList:
            suf = j.split('.')[-1]
            if suf == 'moc':
                os.rename(pre + j, pre + 'model.moc')
            elif suf == 'json':
                newName = 'expressions/' + j.replace('000000', '')
                shutil.move(pre + j, pre + newName)
                example['expressions'].append({'name' : j.replace('000000', ''), 'file' : newName})
                expCnt = expCnt + 1
            elif suf == 'mtn':
                newName = 'motions/' + j.replace('000000', '')
                shutil.move(pre + j, pre + newName)
                example['motions'][''].append({'file' : newName})
                mtnCnt = mtnCnt + 1
            elif suf == 'png':
                newName = 'textures/texture_' + '0' + str(textureCnt) + '.png'
                shutil.move(pre + j, pre + newName)
                example['textures'].append(newName)
                textureCnt = textureCnt + 1
        with open(pre + 'model.json', 'w', encoding="utf-8") as f:
            json.dump(example, f, sort_keys=True, indent=4, separators=(',', ':'))
        sys.stdout.write('完成%s\n' % (i))